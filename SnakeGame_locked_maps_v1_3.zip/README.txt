Snake – All Features (v1.3.0)

NEW: Locked maps (unlocks use OVERALL high score = max(Eat high, Dodge high))
- Neon Maze (unlock 70)
- Portal Rush (unlock 80)
- Spiral Lab (unlock 90)

Existing:
- Crystal Cove (Eat only)
- Bouncing craziness (Dodge only)

How to run:
- Unzip
- Open index.html in Chrome/Safari/Edge
